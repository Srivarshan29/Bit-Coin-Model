// Bitcoin Dashboard JavaScript
class BitcoinDashboard {
    constructor() {
        this.currentPrice = 94383.59;
        this.priceHistory = [];
        this.predictionHistory = [];
        this.charts = {};
        this.updateInterval = null;
        this.init();
    }

    init() {
        // Initialize in correct order
        this.generateInitialData();
        this.setupTabNavigation();
        this.updateMetrics(); // Update metrics immediately
        this.updateTimestamp();
        this.setupModelSelector();
        
        // Initialize charts after a short delay to ensure DOM is ready
        setTimeout(() => {
            this.initializeCharts();
            this.startRealTimeUpdates();
        }, 100);
    }

    setupTabNavigation() {
        const navTabs = document.querySelectorAll('.nav-tab');
        const tabContents = document.querySelectorAll('.tab-content');

        navTabs.forEach(tab => {
            tab.addEventListener('click', (e) => {
                e.preventDefault();
                const targetTab = tab.getAttribute('data-tab');
                
                // Remove active class from all tabs and contents
                navTabs.forEach(t => t.classList.remove('active'));
                tabContents.forEach(content => content.classList.remove('active'));
                
                // Add active class to clicked tab and corresponding content
                tab.classList.add('active');
                const targetContent = document.getElementById(targetTab);
                if (targetContent) {
                    targetContent.classList.add('active');
                }
                
                // Resize charts when tab becomes visible
                setTimeout(() => {
                    if (this.charts.priceChart && targetTab === 'live-data') {
                        this.charts.priceChart.resize();
                    }
                    if (this.charts.predictionChart && targetTab === 'model-predictions') {
                        this.charts.predictionChart.resize();
                    }
                }, 150);
            });
        });
    }

    generateInitialData() {
        // Clear existing data
        this.priceHistory = [];
        this.predictionHistory = [];
        
        // Generate 24 hours of historical price data
        const now = new Date();
        for (let i = 23; i >= 0; i--) {
            const time = new Date(now.getTime() - i * 60 * 60 * 1000);
            const basePrice = 94000 + Math.sin(i * 0.5) * 2000;
            const noise = (Math.random() - 0.5) * 1000;
            const price = Math.max(90000, basePrice + noise);
            
            this.priceHistory.push({
                time: time,
                price: price
            });
        }

        // Generate prediction data
        for (let i = 0; i < 24; i++) {
            const time = new Date(now.getTime() + i * 60 * 60 * 1000);
            const trend = 95000 + Math.sin(i * 0.3) * 1500;
            const confidence = 0.7 + Math.random() * 0.25;
            
            this.predictionHistory.push({
                time: time,
                predicted: trend,
                confidence: confidence
            });
        }
    }

    initializeCharts() {
        this.initializePriceChart();
        this.initializePredictionChart();
    }

    initializePriceChart() {
        const canvas = document.getElementById('price-chart');
        if (!canvas) return;
        
        const ctx = canvas.getContext('2d');
        
        // Destroy existing chart if it exists
        if (this.charts.priceChart) {
            this.charts.priceChart.destroy();
        }
        
        this.charts.priceChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: this.priceHistory.map(item => 
                    item.time.toLocaleTimeString('en-US', { 
                        hour: '2-digit', 
                        minute: '2-digit' 
                    })
                ),
                datasets: [{
                    label: 'Bitcoin Price',
                    data: this.priceHistory.map(item => item.price),
                    borderColor: '#F7931A',
                    backgroundColor: 'rgba(247, 147, 26, 0.1)',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4,
                    pointRadius: 2,
                    pointHoverRadius: 8,
                    pointBackgroundColor: '#F7931A',
                    pointBorderColor: '#F7931A'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    x: {
                        grid: {
                            color: 'rgba(167, 169, 169, 0.2)',
                            drawBorder: false
                        },
                        ticks: {
                            color: '#a7a9a9',
                            maxTicksLimit: 6
                        }
                    },
                    y: {
                        grid: {
                            color: 'rgba(167, 169, 169, 0.2)',
                            drawBorder: false
                        },
                        ticks: {
                            color: '#a7a9a9',
                            callback: function(value) {
                                return '$' + Math.round(value).toLocaleString();
                            }
                        }
                    }
                },
                interaction: {
                    intersect: false,
                    mode: 'index'
                }
            }
        });
    }

    initializePredictionChart() {
        const canvas = document.getElementById('prediction-chart');
        if (!canvas) return;
        
        const ctx = canvas.getContext('2d');
        
        // Destroy existing chart if it exists
        if (this.charts.predictionChart) {
            this.charts.predictionChart.destroy();
        }
        
        const historicalData = this.priceHistory.slice(-12);
        const predictionData = this.predictionHistory.slice(0, 12);
        
        this.charts.predictionChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: [
                    ...historicalData.map(item => 
                        item.time.toLocaleTimeString('en-US', { 
                            hour: '2-digit', 
                            minute: '2-digit' 
                        })
                    ),
                    ...predictionData.map(item => 
                        item.time.toLocaleTimeString('en-US', { 
                            hour: '2-digit', 
                            minute: '2-digit' 
                        })
                    )
                ],
                datasets: [
                    {
                        label: 'Historical Price',
                        data: [
                            ...historicalData.map(item => item.price),
                            ...new Array(predictionData.length).fill(null)
                        ],
                        borderColor: '#1FB8CD',
                        backgroundColor: 'rgba(31, 184, 205, 0.1)',
                        borderWidth: 3,
                        fill: false,
                        tension: 0.4,
                        pointRadius: 2,
                        pointBackgroundColor: '#1FB8CD'
                    },
                    {
                        label: 'Predicted Price',
                        data: [
                            ...new Array(historicalData.length - 1).fill(null),
                            historicalData[historicalData.length - 1].price,
                            ...predictionData.map(item => item.predicted)
                        ],
                        borderColor: '#F7931A',
                        backgroundColor: 'rgba(247, 147, 26, 0.1)',
                        borderWidth: 3,
                        borderDash: [8, 4],
                        fill: false,
                        tension: 0.4,
                        pointRadius: 2,
                        pointBackgroundColor: '#F7931A'
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: true,
                        labels: {
                            color: '#a7a9a9',
                            usePointStyle: true
                        }
                    }
                },
                scales: {
                    x: {
                        grid: {
                            color: 'rgba(167, 169, 169, 0.2)',
                            drawBorder: false
                        },
                        ticks: {
                            color: '#a7a9a9',
                            maxTicksLimit: 8
                        }
                    },
                    y: {
                        grid: {
                            color: 'rgba(167, 169, 169, 0.2)',
                            drawBorder: false
                        },
                        ticks: {
                            color: '#a7a9a9',
                            callback: function(value) {
                                return '$' + Math.round(value).toLocaleString();
                            }
                        }
                    }
                }
            }
        });
    }

    startRealTimeUpdates() {
        // Clear any existing interval
        if (this.updateInterval) {
            clearInterval(this.updateInterval);
        }
        
        this.updateInterval = setInterval(() => {
            this.updatePrice();
            this.updateMetrics();
            this.updateSentiment();
            this.updateSystemStatus();
        }, 3000); // Update every 3 seconds

        // Update timestamp every second
        setInterval(() => {
            this.updateTimestamp();
        }, 1000);
    }

    updatePrice() {
        // Simulate realistic price movement
        const volatility = 0.002; // 0.2% volatility
        const randomChange = (Math.random() - 0.5) * 2 * volatility;
        const trendFactor = Math.sin(Date.now() / 1000000) * 0.001; // Subtle trend
        
        this.currentPrice *= (1 + randomChange + trendFactor);
        
        // Update price display
        const priceElement = document.getElementById('current-price');
        const changeElement = document.getElementById('price-change');
        
        if (priceElement) {
            priceElement.textContent = this.currentPrice.toLocaleString('en-US', {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            });
        }

        // Calculate 24h change (simplified)
        const originalPrice = 94383.59;
        const change24h = ((this.currentPrice - originalPrice) / originalPrice) * 100;
        const changeAmount = this.currentPrice - originalPrice;
        
        if (changeElement) {
            changeElement.className = `price-change ${change24h >= 0 ? 'positive' : 'negative'}`;
            changeElement.innerHTML = `
                <span class="change-value">${change24h >= 0 ? '+' : ''}${change24h.toFixed(2)}%</span>
                <span class="change-amount">${changeAmount >= 0 ? '+' : ''}$${Math.abs(changeAmount).toLocaleString('en-US', { minimumFractionDigits: 2 })}</span>
            `;
        }

        // Update chart
        if (this.charts.priceChart) {
            const now = new Date();
            this.priceHistory.push({
                time: now,
                price: this.currentPrice
            });

            // Keep only last 24 data points
            if (this.priceHistory.length > 24) {
                this.priceHistory.shift();
            }

            this.charts.priceChart.data.labels = this.priceHistory.map(item => 
                item.time.toLocaleTimeString('en-US', { 
                    hour: '2-digit', 
                    minute: '2-digit' 
                })
            );
            this.charts.priceChart.data.datasets[0].data = this.priceHistory.map(item => item.price);
            this.charts.priceChart.update('none');
        }
    }

    updateMetrics() {
        // Calculate metrics from price history
        const prices = this.priceHistory.map(item => item.price);
        const high24h = Math.max(...prices);
        const low24h = Math.min(...prices);
        
        // Update DOM elements
        const high24hElement = document.getElementById('high-24h');
        const low24hElement = document.getElementById('low-24h');
        const volume24hElement = document.getElementById('volume-24h');
        const marketCapElement = document.getElementById('market-cap');
        
        if (high24hElement) {
            high24hElement.textContent = `$${Math.round(high24h).toLocaleString()}`;
        }
        
        if (low24hElement) {
            low24hElement.textContent = `$${Math.round(low24h).toLocaleString()}`;
        }
        
        // Simulate volume changes
        const baseVolume = 56.96;
        const volumeVariation = (Math.random() - 0.5) * 5;
        const currentVolume = Math.max(45, baseVolume + volumeVariation);
        
        if (volume24hElement) {
            volume24hElement.textContent = `$${currentVolume.toFixed(2)}B`;
        }
        
        // Update market cap
        const marketCap = (this.currentPrice * 19.8) / 1000000; // Approximate circulating supply
        
        if (marketCapElement) {
            marketCapElement.textContent = `$${marketCap.toFixed(2)}T`;
        }
    }

    updateSentiment() {
        const sentimentElement = document.getElementById('sentiment-value');
        if (!sentimentElement) return;
        
        // Simulate sentiment changes
        const currentSentiment = parseInt(sentimentElement.textContent) || 72;
        const change = Math.floor((Math.random() - 0.5) * 6);
        const newSentiment = Math.max(0, Math.min(100, currentSentiment + change));
        
        sentimentElement.textContent = newSentiment;
    }

    updateSystemStatus() {
        // Update last update time
        const lastUpdateElement = document.getElementById('last-update');
        if (lastUpdateElement) {
            lastUpdateElement.textContent = new Date().toLocaleTimeString('en-US', {
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit'
            });
        }

        // Simulate system metrics changes
        const cpuUsage = 15 + Math.floor(Math.random() * 20);
        const memoryUsage = 55 + Math.floor(Math.random() * 25);
        const networkLatency = 8 + Math.floor(Math.random() * 15);

        // Find and update system metrics
        const statusItems = document.querySelectorAll('.status-item');
        statusItems.forEach(item => {
            const labelElement = item.querySelector('span:first-child');
            const valueElement = item.querySelector('.status-value');
            
            if (!labelElement || !valueElement) return;
            
            const label = labelElement.textContent.trim();
            
            switch (label) {
                case 'CPU Usage':
                    valueElement.textContent = `${cpuUsage}%`;
                    break;
                case 'Memory Usage':
                    valueElement.textContent = `${memoryUsage}%`;
                    break;
                case 'Network Latency':
                    valueElement.textContent = `${networkLatency}ms`;
                    break;
            }
        });
    }

    updateTimestamp() {
        const now = new Date();
        const options = {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            timeZone: 'Asia/Kolkata',
            timeZoneName: 'short'
        };
        
        const timestampElement = document.getElementById('timestamp');
        if (timestampElement) {
            timestampElement.textContent = now.toLocaleDateString('en-US', options);
        }
    }

    setupModelSelector() {
        const modelSelector = document.getElementById('model-selector');
        const predictedPriceElement = document.getElementById('predicted-price');
        const confidenceLevelElement = document.getElementById('confidence-level');

        const modelPredictions = {
            'lstm': { price: 95750, confidence: 78 },
            'random-forest': { price: 94900, confidence: 66 },
            'xgboost': { price: 95200, confidence: 85 },
            'stock-to-flow': { price: 120000, confidence: 45 },
            'neural-network': { price: 96500, confidence: 82 }
        };

        if (modelSelector) {
            modelSelector.addEventListener('change', (e) => {
                const selectedModel = e.target.value;
                const prediction = modelPredictions[selectedModel];
                
                if (predictedPriceElement && prediction) {
                    predictedPriceElement.textContent = `$${prediction.price.toLocaleString()}`;
                }
                
                if (confidenceLevelElement && prediction) {
                    confidenceLevelElement.textContent = `${prediction.confidence}%`;
                }

                // Update prediction chart based on selected model
                this.updatePredictionChart(selectedModel);
            });
        }
    }

    updatePredictionChart(modelType) {
        if (!this.charts.predictionChart) return;

        // Adjust predictions based on model type
        const modelMultipliers = {
            'lstm': 1.015,
            'random-forest': 1.005,
            'xgboost': 1.008,
            'stock-to-flow': 1.25,
            'neural-network': 1.02
        };

        const multiplier = modelMultipliers[modelType] || 1.01;
        const basePrediction = this.priceHistory[this.priceHistory.length - 1]?.price || this.currentPrice;

        // Update prediction data
        const updatedPredictions = this.predictionHistory.slice(0, 12).map((item, index) => {
            const trendFactor = Math.pow(multiplier, index + 1);
            const randomFactor = 1 + (Math.random() - 0.5) * 0.02;
            return basePrediction * trendFactor * randomFactor;
        });

        const historicalData = this.priceHistory.slice(-12);
        
        this.charts.predictionChart.data.datasets[1].data = [
            ...new Array(historicalData.length - 1).fill(null),
            historicalData[historicalData.length - 1]?.price || this.currentPrice,
            ...updatedPredictions
        ];

        this.charts.predictionChart.update('none');
    }

    // Cleanup method
    destroy() {
        if (this.updateInterval) {
            clearInterval(this.updateInterval);
        }
        
        Object.values(this.charts).forEach(chart => {
            if (chart && typeof chart.destroy === 'function') {
                chart.destroy();
            }
        });
    }
}

// Initialize dashboard when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    console.log('Initializing Bitcoin Dashboard...');
    
    const dashboard = new BitcoinDashboard();
    
    // Store dashboard instance globally for debugging
    window.bitcoinDashboard = dashboard;
    
    // Handle page unload
    window.addEventListener('beforeunload', () => {
        dashboard.destroy();
    });

    // Add interactive effects to cards
    document.querySelectorAll('.metric-card, .model-card, .risk-card, .status-card').forEach(card => {
        card.addEventListener('mouseenter', () => {
            card.style.transform = 'translateY(-2px)';
            card.style.transition = 'transform 0.2s ease';
        });
        
        card.addEventListener('mouseleave', () => {
            card.style.transform = 'translateY(0)';
        });
    });

    // Handle responsive behavior
    const handleResize = () => {
        Object.values(dashboard.charts).forEach(chart => {
            if (chart && typeof chart.resize === 'function') {
                setTimeout(() => chart.resize(), 100);
            }
        });
    };

    window.addEventListener('resize', handleResize);

    console.log('Bitcoin Dashboard initialized successfully');
});